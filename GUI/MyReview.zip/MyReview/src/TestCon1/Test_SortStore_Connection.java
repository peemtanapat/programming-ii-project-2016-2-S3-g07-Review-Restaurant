package TestCon1;

import java.sql.SQLException;
import java.util.ArrayList;
import Codejava1.Restaurant;

public class Test_SortStore_Connection {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        String orderBy = "resName";
        ArrayList<Restaurant> allRestaurant = Restaurant.sortRestaurant(orderBy);
        for(int i=0;i<allRestaurant.size();i++){
            Restaurant r = allRestaurant.get(i);
            System.out.println(r.printAll());           
        }
    }
}
