package myreview;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/**
 *
 * @author INT303
 */
public class ConnectionBuilder {

   public static Connection getConnection() {
        try {
            // เตรียมตัวแปรในการเชื่อมต่อ 
            // url ตามชื่อฐานข้อมูล ส่วน user, pass ตามที่ตั้งค่าตอนติดตั้ง appserv
            String url = "jdbc:derby://localhost:1527/ProJ";
            String user = "db";
            String pass = "db";
            String driver = "org.apache.derby.jdbc.ClientDriver";

            // load driver เข้าสู่หน่วยความจำ
            Class.forName(driver);

            // ทำการเชื่อมต่อฐานข้อมูล และ return
            return DriverManager.getConnection(url, user, pass);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }//end main
}//end class
    

